var searchData=
[
  ['mapa',['mapa',['../class_mapa.html#a67c75bb9ee23bf73c59f432f833fa275',1,'Mapa']]],
  ['mapainicial',['mapaInicial',['../class_mapa.html#a091638a7c1863f4b608120f81f20c6c4',1,'Mapa']]]
];
