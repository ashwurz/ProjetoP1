var searchData=
[
  ['industria',['industria',['../class_veiculos.html#a33ed6f0f0c15becf2516bdc48ad6e3ee',1,'Veiculos']]]
];
