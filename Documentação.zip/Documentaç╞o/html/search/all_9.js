var searchData=
[
  ['veiculos',['Veiculos',['../class_veiculos.html',1,'Veiculos'],['../class_veiculos.html#aea686f1c7d5c5ce1ba6b11b669607151',1,'Veiculos.Veiculos()']]],
  ['velocidade',['velocidade',['../class_veiculos.html#aacc1deb67ebc9c164ebf36bff62dbce0',1,'Veiculos']]]
];
