var searchData=
[
  ['posx',['posx',['../class_veiculos.html#af4483a2892e9359dfd81b5f4335d1425',1,'Veiculos']]],
  ['posy',['posy',['../class_veiculos.html#ab93698c861ceb42dfbba80dd3581d115',1,'Veiculos']]]
];
